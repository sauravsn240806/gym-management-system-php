<?php
error_reporting(0);
require_once('include/config.php');

if (isset($_POST['submit'])) {
    $fname = $_POST['fname'];
    $age = $_POST['age'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $status = $_POST['status'];
    $Password = $_POST['password'];
    $pass = md5($Password);
    $RepeatPassword = $_POST['RepeatPassword'];

    $usermatch = $dbh->prepare("SELECT mobile,email FROM tbluser WHERE (email=:usreml || mobile=:mblenmbr)");
    $usermatch->execute(array(':usreml' => $email, ':mblenmbr' => $mobile));
    while ($row = $usermatch->fetch(PDO::FETCH_ASSOC)) {
        $usrdbeml = $row['email'];
        $usrdbmble = $row['mobile'];
    }

    if (empty($fname)) {
        $error = "Please Enter Full Name";
    } else if (empty($mobile)) {
        $error = "Please Enter Mobile No";
    } else if (empty($email)) {
        $error = "Please Enter Email";
    } else if ($email == $usrdbeml || $mobile == $usrdbmble) {
        $error = "Email Id or Mobile Number Already Exists!";
    } else if ($Password == "" || $RepeatPassword == "") {
        $error = "Password And Confirm Password Must Not Be Empty!";
    } else if ($_POST['password'] != $_POST['RepeatPassword']) {
        $error = "Password And Confirm Password Not Matched";
    } else {
        $sql = "INSERT INTO tbluser (fname, age, email, mobile, gender, address, status, password) 
                VALUES (:fname, :age, :email, :mobile, :gender, :address, :status, :Password)";
        $query = $dbh->prepare($sql);
        $query->bindParam(':fname', $fname, PDO::PARAM_STR);
        $query->bindParam(':age', $age, PDO::PARAM_STR);
        $query->bindParam(':email', $email, PDO::PARAM_STR);
        $query->bindParam(':mobile', $mobile, PDO::PARAM_STR);
        $query->bindParam(':gender', $gender, PDO::PARAM_STR);
        $query->bindParam(':address', $address, PDO::PARAM_STR);
        $query->bindParam(':status', $status, PDO::PARAM_STR);
        $query->bindParam(':Password', $pass, PDO::PARAM_STR);
        $query->execute();
        $lastInsertId = $dbh->lastInsertId();
        if ($lastInsertId > 0) {
            echo "<script>alert('Registration successful. Please login');</script>";
            echo "<script>window.location.href='login.php';</script>";
        } else {
            $error = "Registration Not Successful";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Gym Management System</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" href="css/style.css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background-color:rgb(170, 173, 177);">

<?php include 'include/header.php'; ?>

<section class="contact-page-section spad overflow-hidden">
    <div style="text-align: center;">
        <h2 style="display:inline-block; border: 1px solid; padding: 5px;">Registration Form</h2>
    </div>
    <div class="container mt-4">
        <div class="row">
            <div class="col-lg-2"></div>
            <div class="col-lg-8">
                <?php if ($error) { ?>
                    <div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?></div>
                <?php } ?><br>

                <form class="singup-form contact-form" method="post">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <input type="text" name="fname" id="fname" placeholder="Full Name" autocomplete="off" value="<?php echo $fname; ?>" required>
                        </div>
                        <div class="col-md-6">
                            <input type="number" name="age" id="age" placeholder="Age" autocomplete="off" value="<?php echo $age; ?>" required min="1" max="100">
                        </div>
                        <div class="col-md-6">
                            <input type="email" name="email" id="email" placeholder="Your Email" autocomplete="off" value="<?php echo $email; ?>" required>
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="mobile" id="mobile" maxlength="10" pattern="\d{10}" title="Enter 10 digit mobile number" placeholder="Mobile Number" autocomplete="off" value="<?php echo $mobile; ?>" required>
                        </div>

                        <!-- Gender Dropdown with Placeholder -->
                        <div class="col-md-6">
                            <select name="gender" id="gender" class="form-select" required>
                                <option value="" disabled selected hidden>Gender</option>
                                <option value="Male" <?php if ($gender == 'Male') echo 'selected'; ?>>Male</option>
                                <option value="Female" <?php if ($gender == 'Female') echo 'selected'; ?>>Female</option>
                                <option value="Other" <?php if ($gender == 'Other') echo 'selected'; ?>>Other</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <input type="text" name="address" id="address" placeholder="Address" autocomplete="off" value="<?php echo $address; ?>" required>
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="status" id="status" placeholder="Health Status" autocomplete="off" value="<?php echo $status; ?>" required>
                        </div>
                        <div class="col-md-6">
                            <input type="password" name="password" id="password" placeholder="Password" autocomplete="off" required>
                        </div>
                        <div class="col-md-6">
                            <input type="password" name="RepeatPassword" id="RepeatPassword" placeholder="Confirm Password" autocomplete="off" required>
                        </div>
                        <div class="col-md-4 mt-3">
                            <input type="submit" id="submit" name="submit" value="Register Now" class="site-btn sb-gradient">
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-lg-2"></div>
        </div>
    </div>
</section>

<?php include 'include/footer.php'; ?>

<div class="back-to-top"><img src="img/icons/up-arrow.png" alt=""></div>

<script src="js/vendor/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>

<style>
.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #dd3d36;
    color: #fff;
    box-shadow: 0 1px 1px 0 rgba(0, 0, 0, .1);
}
input[type="text"],
input[type="password"],
input[type="email"],
input[type="number"],
select.form-select {
    border-radius: 0 !important;
    height: 45px;
    font-size: 16px;
    padding: 10px;
}
.site-btn {
    display: inline-block;
    font-size: 16px;
    font-weight: 600;
    border: none;
    padding: 13px 35px;
    min-width: 170px;
    border-radius: 50px;
    text-align: center;
    cursor: pointer;
    color: #fff;
    background: linear-gradient(90deg, #ff5f6d, #ffc371);
    transition: 0.3s;
}
.site-btn:hover {
    opacity: 0.9;
}
</style>
