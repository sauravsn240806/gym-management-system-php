SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- Database: `gymm`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer_pay`
--

CREATE TABLE `customer_pay` (
  `id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_image` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_pay`
--

INSERT INTO `customer_pay` (`id`, `amount`, `payment_image`, `created_at`) VALUES
(1, 200.00, 'uploads/1745661269_Screenshot (1).png', '2025-04-26 09:54:29'),
(5, 50.00, 'uploads/1745662170_Screenshot (1).png', '2025-04-26 10:09:30'),
(6, 5.00, 'uploads/1745662962_Screenshot 2025-01-22 163452.png', '2025-04-26 10:22:42'),
(7, 10.00, 'uploads/1745663461_Screenshot (2).png', '2025-04-26 10:31:01'),
(8, 5.00, 'uploads/1745663579_Screenshot 2025-01-22 163452.png', '2025-04-26 10:32:59'),
(9, 6.00, 'uploads/1745663793_Screenshot (2).png', '2025-04-26 10:36:33'),
(10, 5.00, 'uploads/1745664313_Screenshot 2025-01-22 163452.png', '2025-04-26 10:45:13'),
(11, 5.00, 'uploads/1745664519_Screenshot 2025-01-22 114645.png', '2025-04-26 10:48:39'),
(12, 6.00, 'uploads/1745665061_Screenshot 2025-01-26 112106.png', '2025-04-26 10:57:41');

-- --------------------------------------------------------

--
-- Table structure for table `routine`
--

CREATE TABLE `routine` (
  `id` int(11) NOT NULL,
  `day` varchar(20) DEFAULT NULL,
  `workout_type` varchar(50) DEFAULT NULL,
  `time` time DEFAULT NULL,
  `exercise` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `routine`
--

INSERT INTO `routine` (`id`, `day`, `workout_type`, `time`, `exercise`, `created_at`) VALUES
(4, 'Monday', 'basic', '07:00:00', 'yoga', '2025-05-01 12:22:20');

-- --------------------------------------------------------

--
-- Table structure for table `tbladdpackage`
--

CREATE TABLE `tbladdpackage` (
  `id` int(11) NOT NULL,
  `category` varchar(45) DEFAULT NULL,
  `titlename` varchar(450) DEFAULT NULL,
  `PackageType` varchar(45) DEFAULT NULL,
  `PackageDuratiobn` varchar(45) DEFAULT NULL,
  `Price` varchar(45) DEFAULT NULL,
  `uploadphoto` varchar(450) DEFAULT NULL,
  `Description` varchar(450) DEFAULT NULL,
  `create_date` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbladdpackage`
--

INSERT INTO `tbladdpackage` (`id`, `category`, `titlename`, `PackageType`, `PackageDuratiobn`, `Price`, `uploadphoto`, `Description`, `create_date`) VALUES
(1, '1', 'Free Fitness Gear Package', '1', '3 Month', '4000', NULL, 'Free Fitness Gear\nComplimentary OnePass', '2022-03-05 02:55:34'),
(2, '1', '3 Months Membership Package', '1', '6 Month', '4000', NULL, 'Book Six Days Different Trainers Class designed for fast Weight Loss', '2022-03-05 02:56:44'),
(3, '1', 'hgfhfgdfgdf', '1', '4 Month', '12000', NULL, 'hfdgfhfgh<div><br></div><div>fdgdfg</div>', '2025-05-22 02:34:08');

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `create_date` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`id`, `name`, `email`, `mobile`, `password`, `create_date`) VALUES
(1, 'admin', 'admin@gmail.com', '01608445456', '0192023a7bbd73250516f069df18b500', '2022-01-19 11:25:17');

-- --------------------------------------------------------

--
-- Table structure for table `tblbooking`
--

CREATE TABLE `tblbooking` (
  `id` int(11) NOT NULL,
  `package_id` varchar(45) DEFAULT NULL,
  `userid` varchar(45) DEFAULT NULL,
  `booking_date` timestamp NULL DEFAULT current_timestamp(),
  `payment` varchar(45) DEFAULT NULL,
  `paymentType` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblbooking`
--

INSERT INTO `tblbooking` (`id`, `package_id`, `userid`, `booking_date`, `payment`, `paymentType`) VALUES
(1, '2', '1', '2022-03-05 03:53:21', '800', 'Partial Payment'),
(2, '1', '1', '2022-03-05 03:53:28', '600', 'Partial Payment'),
(3, '2', '5', '2022-03-08 17:44:18', '300', 'Full Payment'),
(6, '1', '5', '2022-05-22 02:16:14', NULL, NULL),
(7, '2', '6', '2022-05-22 02:32:45', NULL, 'Full Payment'),
(8, '1', '7', '2023-10-07 09:56:35', NULL, 'Full Payment'),
(9, '1', '8', '2025-04-26 05:38:49', NULL, NULL),
(10, '1', '8', '2025-04-26 07:25:24', NULL, NULL),
(11, '1', '10', '2025-04-26 08:38:39', NULL, NULL),
(12, '1', '9', '2025-04-26 09:09:39', NULL, NULL),
(13, '1', '9', '2025-04-26 09:23:18', NULL, 'Partial Payment');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `id` int(11) NOT NULL,
  `category_name` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`id`, `category_name`, `status`) VALUES
(1, 'Category1', '0'),
(2, 'Category2', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tblpackage`
--

CREATE TABLE `tblpackage` (
  `id` int(11) NOT NULL,
  `cate_id` varchar(45) DEFAULT NULL,
  `PackageName` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblpackage`
--

INSERT INTO `tblpackage` (`id`, `cate_id`, `PackageName`) VALUES
(1, '1', 'fdgdfg'),
(3, '2', 'Package2');

-- --------------------------------------------------------

--
-- Table structure for table `tblpayment`
--

CREATE TABLE `tblpayment` (
  `id` int(11) NOT NULL,
  `bookingID` varchar(45) DEFAULT NULL,
  `paymentType` varchar(45) DEFAULT NULL,
  `payment` varchar(45) DEFAULT NULL,
  `payment_date` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblpayment`
--

INSERT INTO `tblpayment` (`id`, `bookingID`, `paymentType`, `payment`, `payment_date`) VALUES
(1, '1', 'Partial Payment', '300', '2022-03-05 03:54:10'),
(4, '1', 'Full Payment', '500', '2022-05-22 01:01:58'),
(5, '3', 'Partial Payment', '300', '2022-05-22 01:09:53'),
(8, '3', 'Full Payment', '500', '2022-05-22 01:19:03'),
(9, '7', 'Partial Payment', '500', '2022-05-22 02:40:34'),
(10, '7', 'Full Payment', '300', '2022-05-22 02:41:14'),
(11, '8', 'Partial Payment', '200', '2023-10-07 10:20:42'),
(12, '8', 'Full Payment', '400', '2023-10-07 10:20:57'),
(13, '13', 'Partial Payment', '200', '2025-04-26 09:24:14');

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE `tbluser` (
  `id` int(11) NOT NULL,
  `fname` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `create_date` timestamp NULL DEFAULT current_timestamp(),
  `age` varchar(45) DEFAULT NULL,
  `gender` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`id`, `fname`, `email`, `mobile`, `password`, `address`, `create_date`, `age`, `gender`, `status`) VALUES
(1, 'atul', 'atul@gmail.com', '8888888888', 'f925916e2754e5e03f75dd58a5733251', 'e-48 new asholk nagar hdd ', '2022-02-16 16:48:25', NULL, NULL, NULL),
(2, 'ddd', 'df@gmail.com', '9968556', 'e10adc3949ba59abbe56e057f20f883e', NULL, '2022-02-16 17:00:20', NULL, NULL, NULL),
(3, 'anuj', 'anuj@gmail.com', '9999999999', 'f925916e2754e5e03f75dd58a5733251', NULL, '2022-03-02 15:37:22', NULL, NULL, NULL),
(4, 'sssssss', 'sssssss', 'sssssss', 'f925916e2754e5e03f75dd58a5733251', NULL, '2022-03-05 03:27:28', NULL, NULL, NULL),
(5, 'Anuj k', 'anuj.doca@Gmail.com', '1234567890', '202cb962ac59075b964b07152d234b70', NULL, '2022-03-08 17:43:23', NULL, NULL, NULL),
(6, 'John', 'john@test.com', '1425635241', 'f925916e2754e5e03f75dd58a5733251', 'ABC Street XYZ Colony', '2022-05-22 02:31:54', NULL, NULL, NULL),
(7, 'Md. Mehedi', 'abc@gmail.com', '1608445456', '3f009d72559f51e7e454b16e5d0687a1', NULL, '2023-10-07 09:56:22', NULL, NULL, NULL),
(8, 'sunil', 'sunil@gmail.com', '9808908908', '202cb962ac59075b964b07152d234b70', NULL, '2025-04-26 05:37:50', NULL, NULL, NULL),
(9, 'Raj Shah', 'raj@gmail.com', '9898989898', '202cb962ac59075b964b07152d234b70', NULL, '2025-04-26 08:14:14', NULL, 'Male', 'fat'),
(10, 'khushi', 'khushi@gmail.com', '9878978979', '202cb962ac59075b964b07152d234b70', 'brt', '2025-04-26 08:26:20', NULL, 'female', 'slim'),
(11, 'sabina', 'sabina@gmail.com', '9876543212', '202cb962ac59075b964b07152d234b70', 'brt', '2025-04-26 08:33:14', '24', 'female', 'chubby');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer_pay`
--
ALTER TABLE `customer_pay`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `routine`
--
ALTER TABLE `routine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbladdpackage`
--
ALTER TABLE `tbladdpackage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbooking`
--
ALTER TABLE `tblbooking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpackage`
--
ALTER TABLE `tblpackage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpayment`
--
ALTER TABLE `tblpayment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tbluser`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer_pay`
--
ALTER TABLE `customer_pay`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `routine`
--
ALTER TABLE `routine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbladdpackage`
--
ALTER TABLE `tbladdpackage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblbooking`
--
ALTER TABLE `tblbooking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblpackage`
--
ALTER TABLE `tblpackage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblpayment`
--
ALTER TABLE `tblpayment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbluser`
--
ALTER TABLE `tbluser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
