

<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "gymm"); // <-- change db name here

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$booking_id = $_GET['bookingid'];
// Get payment amount
$amount = $_POST['amount'];

// Upload image
if (isset($_FILES['payment_image']) && $_FILES['payment_image']['error'] == 0) {
    $targetDir = "uploads/"; // Create uploads/ folder if not exist
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    $filename = basename($_FILES['payment_image']['name']);
    $targetFilePath = $targetDir . time() . "_" . $filename; 

    if (move_uploaded_file($_FILES['payment_image']['tmp_name'], $targetFilePath)) {
        // Insert into database
        $stmt = $conn->prepare("INSERT INTO customer_pay (amount, payment_image) VALUES (?, ?)");
        $stmt->bind_param("ds", $amount, $targetFilePath);
        if ($stmt->execute()) {
            echo "<script>
                alert('Payment Done Successfully!');

                // Get bookingid from the URL
                const urlParams = new URLSearchParams(window.location.search);
                const booking_id = urlParams.get('bookingid');
                
                // Redirect to the booking-details page with the booking_id
                if (booking_id) {
                    window.location.href = 'booking-details.php?bookingid=' + booking_id;
                } else {
                    alert('Booking ID not found!');
                }
            </script>";
        } else {
            echo "Error saving payment. Try again.";
        }
        $stmt->close();
    } else {
        echo "Error uploading image.";
    }
} else {
    echo "Please upload an image.";
}

$conn->close();
?>
