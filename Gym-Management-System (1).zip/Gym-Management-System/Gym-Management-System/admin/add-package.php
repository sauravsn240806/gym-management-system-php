<?php
session_start();
error_reporting(0);
include 'include/config.php';
if (strlen($_SESSION['adminid'] == 0)) {
    header('location:logout.php');
} else {
    if (isset($_POST['submit'])) {
        $AddPackage = $_POST['addPackage'];
        $category = $_POST['category'];
        $sql = "INSERT INTO tblpackage (PackageName, cate_id) VALUES (:Package, :category)";
        $query = $dbh->prepare($sql);
        $query->bindParam(':Package', $AddPackage, PDO::PARAM_STR);
        $query->bindParam(':category', $category, PDO::PARAM_STR);
        $query->execute();
        $lastInsertId = $dbh->lastInsertId();
        if ($lastInsertId > 0) {
            $msg = "Package Added Successfully";
            echo "<script>window.location.href='add-package.php'</script>";
        } else {
            $errormsg = "Data not inserted successfully";
        }
    }

    // Delete Record
    if (isset($_REQUEST['del'])) {
        $uid = intval($_GET['del']);
        $sql = "DELETE FROM tblpackage WHERE id=:id";
        $query = $dbh->prepare($sql);
        $query->bindParam(':id', $uid, PDO::PARAM_STR);
        $query->execute();
        echo "<script>alert('Record Deleted successfully');</script>";
        echo "<script>window.location.href='add-package.php'</script>";
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin | Add Package Type</title>
    <meta charset="utf-8">
    <meta name="description" content="Vali is a">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css"
          href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body class="app sidebar-mini rtl">
<?php include 'include/header.php'; ?>
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<?php include 'include/sidebar.php'; ?>

<main class="app-content">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Package Types</h3>
        <button id="showFormBtn" class="btn btn-success">Add Package</button>
    </div>
    <hr/>

    <!-- Table Row -->
    <div class="row" id="packageFormFirstRow">
        <div class="col-md-12">
            <div class="tile">
                <div class="tile-body">
                    <table class="table table-hover table-bordered" id="sampleTable">
                        <thead>
                        <tr>
                            <th>Sr.No</th>
                            <th>Category</th>
                            <th>Package</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $sql = "SELECT * FROM tblpackage 
                                JOIN tblcategory 
                                ON tblpackage.cate_id = tblcategory.id";
                        $query = $dbh->prepare($sql);
                        $query->execute();
                        $results = $query->fetchAll(PDO::FETCH_OBJ);
                        $cnt = 1;
                        if ($query->rowCount() > 0) {
                            foreach ($results as $result) {
                                ?>
                                <tr>
                                    <td><?php echo $cnt; ?></td>
                                    <td><?php echo htmlentities($result->category_name); ?></td>
                                    <td><?php echo htmlentities($result->PackageName); ?></td>
                                    <td>
                                        <a href="add-package.php?del=<?php echo htmlentities($result->id); ?>">
                                            <button class="btn btn-danger" type="button">Delete</button>
                                        </a>
                                    </td>
                                </tr>
                                <?php $cnt++;
                            }
                        } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Hidden Form Row -->
    <div class="row" id="packageFormRow" style="display: none;">
        <div class="col-md-6">
            <div class="tile">
                <!-- Success Message -->
                <?php if ($msg) { ?>
                    <div class="alert alert-success" role="alert">
                        <strong>Well done!</strong> <?php echo htmlentities($msg); ?>
                    </div>
                <?php } ?>
                <!-- Error Message -->
                <?php if ($errormsg) { ?>
                    <div class="alert alert-danger" role="alert">
                        <strong>Oh snap!</strong> <?php echo htmlentities($errormsg); ?>
                    </div>
                <?php } ?>

                <form class="row" method="post">
                    <div class="form-group col-md-12">
                        <label class="control-label">Select Category</label>
                        <select class="form-control" name="category" id="category">
                            <option value="NA">--select--</option>
                            <?php
                            $stmt = $dbh->prepare("SELECT * FROM tblcategory ORDER BY category_name");
                            $stmt->execute();
                            $categories = $stmt->fetchAll();
                            foreach ($categories as $cat) {
                                echo "<option value='" . $cat['id'] . "'>" . $cat['category_name'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="form-group col-md-12">
                        <label class="control-label">Add Package</label>
                        <input class="form-control" name="addPackage" id="addPackage" type="text"
                               placeholder="Enter Package Name">
                    </div>
                    <div class="form-group col-md-4 align-self-end">
                        <input type="submit" name="submit" id="submit" class="btn btn-primary" value="Submit">
                    </div>
                </form>
            </div>
        </div>
    </div>

</main>
<?php include_once 'include/footer.php'; ?>

<!-- JS Dependencies -->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
<script src="js/plugins/pace.min.js"></script>
<script src="js/plugins/jquery.dataTables.min.js"></script>
<script src="js/plugins/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">$('#sampleTable').DataTable();</script>

<!-- Toggle Form Script -->
<script>
    document.getElementById("showFormBtn").addEventListener("click", function () {
        var formRow = document.getElementById("packageFormRow");
        var formFirstRow = document.getElementById("packageFormFirstRow");
        if (formRow.style.display === "none" || formRow.style.display === "") {
            formRow.style.display = "flex";
            showFormBtn.textContent = "Show package";
            formFirstRow.style.display = "none";
        } else {
            formRow.style.display = "none";
            showFormBtn.textContent = "Add package";
            formFirstRow.style.display = "flex";
        }
    });
</script>

</body>
</html>
<?php } ?>
