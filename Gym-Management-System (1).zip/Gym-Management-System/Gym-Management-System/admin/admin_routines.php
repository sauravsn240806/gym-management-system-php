<?php
session_start();
error_reporting(0);
include 'include/config.php';

if (strlen($_SESSION['adminid']) == 0) {
    header('location:logout.php');
    exit;
}

// Handle delete request
if (isset($_GET['delid'])) {
    $delid = $_GET['delid'];
    $sql = "DELETE FROM routine WHERE id = :delid";
    $query = $dbh->prepare($sql);
    $query->bindParam(':delid', $delid, PDO::PARAM_INT);
    $query->execute();

    // Redirect to the same page after deletion
    header("Location: admin_routines.php");
    exit;
}

// Fetch all routines
$sql = "SELECT * FROM routine ORDER BY created_at DESC";
$query = $dbh->prepare($sql);
$query->execute();
$routines = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Routines</title>
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body class="app sidebar-mini rtl">
    <?php include 'include/header.php'; ?>
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <?php include 'include/sidebar.php'; ?>

    <main class="app-content">
        <h2 class="mb-4">All Added Workout Routines</h2>

        <div class="table-responsive">
            <table class="table table-bordered" id="sampleTable">
                <thead>
                    <tr>
                        <th>Day</th>
                        <th>Workout Type</th>
                        <th>Time</th>
                        <th>Exercise</th>
                        <th>Created At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($routines): ?>
                        <?php foreach ($routines as $row): ?>
                            <tr>
                                <td><?php echo htmlentities($row['day']); ?></td>
                                <td><?php echo htmlentities($row['workout_type']); ?></td>
                                <td><?php echo htmlentities($row['time']); ?></td>
                                <td><?php echo htmlentities($row['exercise']); ?></td>
                                <td><?php echo htmlentities($row['created_at']); ?></td>
                                <td>
                                    <!-- <a href="edit-routine.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-warning">Edit</a> -->
                                    <a href="admin_routines.php?delid=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this routine?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="6">No routine added yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

    <?php include_once 'include/footer.php'; ?>
    <!-- JS scripts -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/plugins/pace.min.js"></script>
    <script src="js/plugins/jquery.dataTables.min.js"></script>
    <script src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">
        $('#sampleTable').DataTable();
    </script>
</body>
</html>
