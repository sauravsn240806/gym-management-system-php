<?php  session_start();
error_reporting(0);
include  'include/config.php'; 
if (strlen($_SESSION['adminid']==0)) {
  header('location:logout.php');
  } else{
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    
    <title>Admin | Dashboard</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
    body {
      background-color: #f4f6f9;
    }
    .sidebar {
      height: 100vh;
      background-color: #2c3e50;
    }
    .sidebar a {
      color: #ecf0f1;
      text-decoration: none;
    }
    .sidebar a:hover {
      background-color: #34495e;
    }
    .dashboard-card {
      border: none;
      border-radius: 20rem;
      color: #fff;
      padding: 20px;
      height: 100px;
      transition: transform 0.3s ease-in-out;
    }
    .dashboard-card:hover {
      transform: scale(1.05);
    }
    .col-md-4{
      margin-bottom: 2%;
    }

    
  </style>



  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
    <?php include 'include/header.php'; ?>
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <?php include 'include/sidebar.php'; ?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i> Dashboard</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
        </ul>
      </div>
     

 
<div class="row mb-3">
  <!-- Listed Categories -->
  <div class="col-md-3 mb-4">
    <?php
    $sql = "SELECT count(id) as totalcat FROM tblcategory;";
    $query = $dbh->prepare($sql);
    $query->execute();
    $results = $query->fetchAll(PDO::FETCH_OBJ);
    foreach($results as $result) {
    ?>
    <a href="add-category.php" style="text-decoration: none;">
      <div class="dashboard-card bg-info text-white p-4 shadow-sm d-flex flex-column align-items-center justify-content-center text-center" style="border-radius: 2rem;">
        
        <!-- Number in Circle -->
        <div class="d-flex justify-content-center align-items-center bg-white text-info mb-3" 
             style="width: 80px; height: 80px; border-radius: 50%; font-size: 1.8rem; font-weight: bold;">
          <?php echo $result->totalcat; ?>
        </div>
        
        <!-- Label -->
        <div>
          <h5 class="mb-0 text-white">Listed Categories</h5>
        </div>
        
      </div>
    </a>
    <?php } ?>
  </div>



  <!-- Listed Package Types -->
<div class="col-md-3 mb-4">
  <?php
  $sql = "SELECT count(id) as totalpackagetype FROM tblcategory;";
  $query = $dbh->prepare($sql);
  $query->execute();
  $results = $query->fetchAll(PDO::FETCH_OBJ);
  foreach($results as $result) {
  ?>
  <a href="add-package.php" style="text-decoration: none;">
    <div class="dashboard-card bg-primary text-white p-4 shadow-sm d-flex flex-column align-items-center justify-content-center text-center" style="border-radius: 2rem;">

      <!-- Number in Circle -->
      <div class="d-flex justify-content-center align-items-center bg-white text-primary mb-3" 
           style="width: 80px; height: 80px; border-radius: 50%; font-size: 1.8rem; font-weight: bold;">
        <?php echo $result->totalpackagetype; ?>
      </div>

      <!-- Label -->
      <div>
        <h5 class="mb-0 text-white">Listed Package Type</h5>
      </div>

    </div>
  </a>
  <?php } ?>
</div>

  <!-- Listed Packages -->
 <div class="col-md-3 mb-4">
  <?php
  $sql = "SELECT count(id) as totalpost FROM tbladdpackage;";
  $query = $dbh->prepare($sql);
  $query->execute();
  $results = $query->fetchAll(PDO::FETCH_OBJ);
  foreach($results as $result) {
  ?>
  <a href="manage-post.php" style="text-decoration: none;">
    <div class="dashboard-card bg-dark text-white p-4 shadow-sm d-flex flex-column align-items-center justify-content-center text-center" style="border-radius: 2rem;">

      <!-- Number in Circle -->
      <div class="d-flex justify-content-center align-items-center bg-white text-dark mb-3"
           style="width: 80px; height: 80px; border-radius: 50%; font-size: 1.8rem; font-weight: bold;">
        <?php echo $result->totalpost; ?>
      </div>

      <!-- Label -->
      <div>
        <h5 class="mb-0 text-white">Listed Packages</h5>
      </div>

    </div>
  </a>
  <?php } ?>
</div>


  <!-- Total Bookings -->
  <div class="col-md-3 mb-4">
  <?php
  $sql = "SELECT count(id) as totalbookings FROM tblbooking;";
  $query = $dbh->prepare($sql);
  $query->execute();
  $results = $query->fetchAll(PDO::FETCH_OBJ);
  foreach($results as $result) {
  ?>
  <a href="booking-history.php" style="text-decoration: none;">
    <div class="dashboard-card bg-secondary text-white p-4 shadow-sm d-flex flex-column align-items-center justify-content-center text-center" style="border-radius: 2rem;">

      <!-- Number in Circle -->
      <div class="d-flex justify-content-center align-items-center bg-white text-secondary mb-3"
           style="width: 80px; height: 80px; border-radius: 50%; font-size: 1.8rem; font-weight: bold;">
        <?php echo $result->totalbookings; ?>
      </div>

      <!-- Label -->
      <div>
        <h5 class="mb-0 text-white">Total Bookings</h5>
      </div>

    </div>
  </a>
  <?php } ?>
</div>

</div>

<div class="row">
  <!-- New Bookings -->
  <div class="col-md-3 mb-4">
  <?php
  $sql = "SELECT count(id) as totalbookings FROM tblbooking WHERE paymentType IS NULL OR paymentType=''";
  $query = $dbh->prepare($sql);
  $query->execute();
  $results = $query->fetchAll(PDO::FETCH_OBJ);
  foreach($results as $result) {
  ?>
  <a href="new-bookings.php" style="text-decoration: none;">
    <div class="dashboard-card bg-danger text-white p-4 shadow-sm d-flex flex-column align-items-center justify-content-center text-center" style="border-radius: 2rem;">

      <!-- Number in Circle -->
      <div class="d-flex justify-content-center align-items-center bg-white text-danger mb-3"
           style="width: 80px; height: 80px; border-radius: 50%; font-size: 1.8rem; font-weight: bold;">
        <?php echo $result->totalbookings; ?>
      </div>

      <!-- Label -->
      <div>
        <h5 class="mb-0 text-white">New Bookings</h5>
      </div>

    </div>
  </a>
  <?php } ?>
</div>


  <!-- Partial Payment Bookings -->
<div class="col-md-3 mb-4">
  <?php
  $sql = "SELECT count(id) as totalbookings FROM tblbooking WHERE paymentType='Partial Payment'";
  $query = $dbh->prepare($sql);
  $query->execute();
  $results = $query->fetchAll(PDO::FETCH_OBJ);
  foreach($results as $result) {
  ?>
  <a href="partial-payment-bookings.php" style="text-decoration: none;">
    <div class="dashboard-card bg-success text-white p-4 shadow-sm d-flex flex-column align-items-center justify-content-center text-center" style="border-radius: 2rem;">

      <!-- Number in Circle -->
      <div class="d-flex justify-content-center align-items-center bg-white text-success mb-3"
           style="width: 80px; height: 80px; border-radius: 50%; font-size: 1.8rem; font-weight: bold;">
        <?php echo $result->totalbookings; ?>
      </div>

      <!-- Label -->
      <div>
        <h5 class="mb-0 text-white">Partial Pay Bookings</h5>
      </div>

    </div>
  </a>
  <?php } ?>
</div>



  <!-- Full Payment Bookings -->
  <div class="col-md-3 mb-4">
  <?php
  $sql = "SELECT count(id) as totalbookings FROM tblbooking WHERE paymentType='Full Payment'";
  $query = $dbh->prepare($sql);
  $query->execute();
  $results = $query->fetchAll(PDO::FETCH_OBJ);
  foreach($results as $result) {
  ?>
  <a href="full-payment-bookings.php" style="text-decoration: none;">
    <div class="dashboard-card bg-warning text-white p-4 shadow-sm d-flex flex-column align-items-center justify-content-center text-center" style="border-radius: 2rem;">

      <!-- Number in Circle -->
      <div class="d-flex justify-content-center align-items-center bg-white text-warning mb-3"
           style="width: 80px; height: 80px; border-radius: 50%; font-size: 1.8rem; font-weight: bold;">
        <?php echo $result->totalbookings; ?>
      </div>

      <!-- Label -->
      <div>
        <h5 class="mb-0 text-white">Full Pay Bookings</h5>
      </div>

    </div>
  </a>
  <?php } ?>
</div>

</div>

     
     
    </main>

    <?php include_once 'include/footer.php' ?>
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Data table plugin-->
    <script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
   
  </body>
</html>
<?php } ?>