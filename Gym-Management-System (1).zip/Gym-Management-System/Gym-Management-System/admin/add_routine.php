<?php 
session_start();
error_reporting(0);
include 'include/config.php';

if (strlen($_SESSION['adminid']) == 0) {
    header('location:logout.php');
    exit;
}

if (isset($_POST['submit'])) {
    $day = $_POST['day'];
    $workout_type = $_POST['workout_type'];
    $time = $_POST['time'];
    $exercise = $_POST['exercise'];

    $sql = "INSERT INTO routine (day, workout_type, time, exercise) 
            VALUES (:day, :workout_type, :time, :exercise)";
    $query = $dbh->prepare($sql);
    $query->bindParam(':day', $day, PDO::PARAM_STR);
    $query->bindParam(':workout_type', $workout_type, PDO::PARAM_STR);
    $query->bindParam(':time', $time, PDO::PARAM_STR);
    $query->bindParam(':exercise', $exercise, PDO::PARAM_STR);

    if ($query->execute()) {
        $msg = "Routine added successfully!";
    } else {
        $errormsg = "Failed to add routine!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Routine</title>
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Flatpickr CSS (for date picker) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
</head>
<body class="app sidebar-mini rtl">
    <?php include 'include/header.php'; ?>
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <?php include 'include/sidebar.php'; ?>

    <main class="app-content">
        <h2 class="mb-4">Add Workout Routine</h2>

        <?php if ($msg): ?>
            <div class="alert alert-success"><?php echo $msg; ?></div>
        <?php elseif ($errormsg): ?>
            <div class="alert alert-danger"><?php echo $errormsg; ?></div>
        <?php endif; ?>

        <form method="post" class="border p-4 rounded bg-light">
            <!-- Day Selection as Dropdown -->
            <div class="mb-3">
                <label for="day" class="form-label">Day</label>
                <select class="form-control" id="day" name="day" required>
                    <option value="Sunday">Sunday</option>
                    <option value="Monday">Monday</option>
                    <option value="Tuesday">Tuesday</option>
                    <option value="Wednesday">Wednesday</option>
                    <option value="Thursday">Thursday</option>
                    <option value="Friday">Friday</option>
                    <option value="Saturday">Saturday</option>
                </select>
            </div>

            <!-- Workout Type Input -->
            <div class="mb-3">
                <label for="workout_type" class="form-label">Workout Type</label>
                <input type="text" class="form-control" id="workout_type" name="workout_type" required>
            </div>

            <!-- Time Selection using Flatpickr -->
            <div class="mb-3">
                <label for="time" class="form-label">Time</label>
                <input type="text" class="form-control" id="time" name="time" required placeholder="Select Time">
            </div>

            <!-- Exercise Details Input -->
            <div class="mb-3">
                <label for="exercise" class="form-label">Exercise Details</label>
                <textarea class="form-control" id="exercise" name="exercise" rows="4" required></textarea>
            </div>

            <!-- Submit Button -->
            <button type="submit" name="submit" class="btn btn-primary">Add Routine</button>
        </form>
    </main>

    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/plugins/pace.min.js"></script>

    <!-- Flatpickr JS for Time Picker -->
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        // Initialize flatpickr on the time input
        flatpickr("#time", {
            enableTime: true,
            noCalendar: true,
            dateFormat: "H:i", // Only time format
        });
    </script>
</body>
</html>
