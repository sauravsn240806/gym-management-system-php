<style>
table {
    left: 20%;
    width: 80%;
    border-collapse: collapse;
    margin-top: 20px;
}
th, td {
    padding: 12px;
    text-align: center;
    border: 1px solid #ddd;
}
th {
    background-color: #f2f2f2;
}

table {
    width: 80%;
    position: relative;
    border-collapse: collapse;
    margin-top: 20px;
}
th, td {
    padding: 12px;
    text-align: center;
    border: 1px solid #ddd;
}
th {
    background-color: #f2f2f2;
}

/* Zoom image style */
.zoomed {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%) scale(8); /* Change scale to 3x */
    z-index: 9999;
    border: 5px solid #ccc;
    background: #fff;
    box-shadow: 0px 0px 20px rgba(0,0,0,0.5);
    transition: all 0.3s ease; /* smooth animation */
}

</style>
<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "gymm");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch payment records
$sql = "SELECT * FROM customer_pay ORDER BY id DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="description" content="Vali is a">
   <title>Admin | Add Package</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->

    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
   <?php include 'include/header.php'; ?>
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <?php include 'include/sidebar.php'; ?>
<h2>Payment Records</h2>

<table border="1" cellpadding="10" cellspacing="0">
    <thead>
        <tr>
            <th>ID</th>
            <!-- <th>user_name</th> -->
            <th>Amount</th>
            <th>Payment Image</th>
            <th>Created At</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlentities($row['id']) . "</td>";
                echo "<td>Rs" . htmlentities($row['amount']) . "</td>";
                echo "<td><img src='../" . htmlentities($row['payment_image']) . "' width='100' height='80' class='zoomable' onclick='zoomImage(this)'></td>";
                echo "<td>" . htmlentities($row['created_at']) . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No records found</td></tr>";
        }
        ?>
        <script>
            function zoomImage(img) {
                if (img.classList.contains('zoomed')) {
                    img.classList.remove('zoomed');
                } else {
                    // Remove zoom from any other image
                    document.querySelectorAll('.zoomable').forEach(function(otherImg){
                        otherImg.classList.remove('zoomed');
                    });
                    img.classList.add('zoomed');
                }
            }
        </script>
    </tbody>   
</table>
<?php
$conn->close();
?>
  </body>
  </html>
