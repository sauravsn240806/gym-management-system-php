<footer style="text-align: center; padding: 5px 10px; color: white; background-color: #000;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-auto">
                <div class="copyright" style="color:#fff;">
                    &copy; PowerFit Gym <?php echo date('Y'); ?>
                </div>
            </div>
        </div>
    </div>
</footer>
