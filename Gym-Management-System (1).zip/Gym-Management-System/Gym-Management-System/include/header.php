<?php
session_start(); // make sure you have session_start() at the beginning

// Assuming you have user full name stored in session like:
// $_SESSION['name'] = "Sunil Mehta";

function getUserInitials($fullName) {
    $names = explode(' ', $fullName);
    $initials = '';
    foreach ($names as $n) {
        $initials .= strtoupper($n[0]);
    }
    return $initials;
}
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">

        <!-- <button onclick="history.back()" class="btn btn-primary" style="margin-right:10px;"> < </button> -->
        <i class="fas fa-dumbbell text-white mr-2"></i>
        <a class="navbar-brand" href="#">PowerFit Gym</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="/Gym-Management-System/#Service">Service</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/Gym-Management-System/#features">Features</a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="/Gym-Management-System/#testimonials">Testimonials</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/Gym-Management-System/#memberships">Memberships</a>
                </li>
               
                <?php if (strlen($_SESSION['uid']) != 0): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="booking-history.php">Booking History</a>
                    </li>
                <?php endif; ?>

                <?php if(strlen($_SESSION['uid']) == 0): ?>
                    <!-- If not logged in -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="loginDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Login
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="loginDropdown">
                            <li><a class="dropdown-item" href="login.php">User Login</a></li>
                            <li><a class="dropdown-item" href="admin/login.php">Admin Login</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                  
                <?php if (strlen($_SESSION['uid']) != 0): ?>
                    <!-- If the user is logged in, show Change Password and Logout links -->
            
                <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link" href="view_routine.php">Routine</a>
                    </li>

					  <!-- If logged in -->
                      <li class="nav-item dropdown" style="margin-left: 100px;">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            style="border-radius: 20px; background: rgb(14, 183, 11); color: white;">
                                <?php echo getUserInitials($_SESSION['name']); ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                                <li><a class="dropdown-item" href="changepassword.php">Change Password</a></li>
                                <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                            </ul>
                        </li>

					
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
