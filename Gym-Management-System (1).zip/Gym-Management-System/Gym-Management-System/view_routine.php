<?php
include 'include/config.php';

// Fetch all routines from the database
$sql = "SELECT * FROM routine ORDER BY created_at DESC";
$query = $dbh->prepare($sql);
$query->execute();
$routines = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Routines</title>
    <!-- Main CSS-->
    <!-- <link rel="stylesheet" type="text/css" href="css/main.css"> -->
    <link rel="stylesheet" href="css/style.css"/>
 
    <!-- Font-icon css-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .page-top-section {
            height: 478px;
            position: relative;
            padding-top: 220px;
            text-align: center;
            background-image: url(img/page-top-bg.jpg);
        }
        .mt-5 {
            margin: -1% 15% 10% 16%;
            /* margin-top: 11rem !important; */
            background-color: #2c3e50;
        }
    </style>




</head>
<body class="app sidebar-mini rtl">

    <!-- Navbar (include header.php for general navigation) -->
    <?php include 'include/header.php'; ?>
    <!-- <section class="page-top-section set-bg" data-setbg="img/page-top-bg.jpg">
		<div class="container">
			<div class="row">
				<div class="col-lg-7 m-auto text-white">
					<h2>Routine</h2>
					
				</div>
			</div>
		</div>
	</section> -->
    <div style="height:200px"></div>
    <main class="app-content mt-5"> <!-- Added margin-top -->
        <h2 class="mb-4">View Workout Routines</h2>

        <div class="table-responsive">
            <table class="table table-bordered table-striped" id="sampleTable"> <!-- Added table-striped for better table design -->
                <thead>
                    <tr>
                        <th>Day</th>
                        <th>Workout Type</th>
                        <th>Time</th>
                        <th>Exercise</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($routines): ?>
                        <?php foreach ($routines as $row): ?>
                            <tr>
                                <td><?php echo htmlentities($row['day']); ?></td>
                                <td><?php echo htmlentities($row['workout_type']); ?></td>
                                <td><?php echo htmlentities($row['time']); ?></td>
                                <td><?php echo htmlentities($row['exercise']); ?></td>
                                <td><?php echo htmlentities($row['created_at']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="5">No routine available.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

    <?php include_once 'include/footer.php'; ?>

    <!-- Essential javascripts for application to work-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/plugins/pace.min.js"></script>
    <script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>

</body>
</html>
