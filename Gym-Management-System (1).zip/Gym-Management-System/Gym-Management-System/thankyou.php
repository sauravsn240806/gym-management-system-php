<?php
echo "<h2>Thank you! Your payment has been received.</h2>";
?>